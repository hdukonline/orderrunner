"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const test_1 = require("@playwright/test");
const login_definition_1 = require("../playwright/tests/login.definition");
(0, test_1.test)("Arena Login test", async ({ page }) => {
    await login_definition_1.loginTest.run(page, {
        test: "login",
        browser: "chromium",
        runs: 1,
        headless: true,
        screenshot: false,
        report: false,
    });
});
