import { test } from "@playwright/test";
import { loginTest } from "../playwright/tests/login.definition";

test("Arena Login test", async ({ page }) => {
    await loginTest.run(page, {
        test: "login",
        browser: "chromium",
        runs: 1,
        headless: true,
        screenshot: false,
        report: false,
    });
});