import { TestDefinition } from "../types";

export const loginTest: TestDefinition = {
    name: "login",
    site: "arena",

    async run(page, options, log) {
        log?.("Navigating to arena home page... ");
        await page.goto("https://arena-dev.hblonline.co.uk"); // Placeholder - comes from app

        log?.("Clicking Sign in button");
        await page.locator('div.l-header__login a.c-button', { hasText: 'Sign in' }).first().click();

        if (options.screenshot) {
            await page.screenshot({ path: `arena-login-${Date.now()}.png` });
        }
    },
};

export const portalLoginTest: TestDefinition = {
    name: "login",
    site: "portal",

    async run(page, options) {
        await page.goto("https://tp-fe-dev.hblonline.co.uk/"); // Placeholder - comes from app

        if (options.screenshot) {
            await page.screenshot({ path: `portal-login-${Date.now()}.png` });
        }
    },
};