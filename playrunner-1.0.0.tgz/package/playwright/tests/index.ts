import { TestDefinition } from "../types";
import { loginTest, portalLoginTest } from "./login.definition";
// import { searchTest } from "./search.definition";
// import { siteTest } from "./site.definition";

/**
 * Central registry of available tests
 */
export const tests: Record<string, Record<string, TestDefinition>> = {
    login: {
        arena: loginTest,
        portal: portalLoginTest,
    },
    //search: {
    // arena: searchTest
    // portal ommitted not included
    //},
};