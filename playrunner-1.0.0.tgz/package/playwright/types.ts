import { Page } from "playwright";
import { RunOptions } from "./runner";

/**
 * Standard interface all tests must implement
 */
export interface TestDefinition {
    name: string;
    site?: string;
    //run: (page: Page, options: RunOptions) => Promise<void>;
    run: (page: Page, options: RunOptions, onLog?: (msg: string) => void) => Promise<void>;
}