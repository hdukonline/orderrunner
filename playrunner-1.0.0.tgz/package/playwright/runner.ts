import { chromium, firefox, webkit, Browser, Page } from "playwright";
import { tests } from "./tests";
import { TestDefinition } from "./types";
import path from "path";
import fs from "fs";

/**
 * Base options for all tests.
 * Per-test interfaces can extend this with additional fields.
 */
export interface RunOptions {
  test: string;  // Which test to run
  site?: string;
  browser: "chromium" | "firefox" | "webkit";
  runs: number;
  headless: boolean;
  screenshot: boolean;
  report: boolean;
}

/**
 * Example extension for site-specific tests
 */
export interface SiteTestOptions extends RunOptions {
  url?: string;
  environment?: "dev" | "qa" | "prod";
}

/**
 * Example extension for login-specific tests
 */
export interface LoginTestOptions extends RunOptions {
  username?: string;
  password?: string;
}

/**
 * runTest has an optional logging callback
 * so messages can be streamed back to the UI live
 */
export async function runTest(
  options: RunOptions,
  onLog?: (message: string) => void
): Promise<string> {
  let browserInstance: Browser | null = null;
  let page: Page | null = null;

  // Helper to send logs either via callback or console
  const log = (message: string) => {
    if (onLog) onLog(message);
    else console.log(message);
  };

  try {
    log(`Launching browser: ${options.browser}...`);

    /* Launch browser */
    browserInstance = await { chromium, firefox, webkit }[options.browser].launch({
      headless: options.headless,

    });

    const context = await browserInstance.newContext();
    page = await context.newPage();

    log(`Looking up test: ${options.test}`);
    /* Lookup test */
    const test: TestDefinition | undefined = tests[options.test]?.[options.site!];

    if (!test) {
      throw new Error(`Test not found: ${options.test} for site ${options.site}`);
    }

    log(`Executing test: ${options.test}`);

    await test.run(page, options, log);

    log(`Closing browser...`);
    await browserInstance.close();

    const successMessage = `Test "${options.test}" completed successfully`;
    log(successMessage);
    return successMessage;

  } catch (err: any) {

    if (page) {
      const dir = path.resolve("screenshots");
      fs.mkdirSync(dir, { recursive: true });

      const filePath = path.join(
        dir,
        `failure-${options.test}-${Date.now()}.png`
      );

      await page.screenshot({ path: filePath, fullPage: true });
      log(`Screenshot saved: ${filePath}`);
    }

    if (browserInstance) {
      await browserInstance.close();
    }

    log(`Error: ${err.message}`);
    throw err;
  }
}
