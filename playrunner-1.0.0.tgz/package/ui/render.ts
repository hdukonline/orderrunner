export { };

/* ------------------------------------------------------------------ */
/* WINDOW API TYPES                                                   */
/* ------------------------------------------------------------------ */

/**
 * Expose IPC API typings on window
 * (Electron preload pattern)
 */
declare global {
  interface Window {
    api: {
      runTest: (options: RunOptions) => Promise<string>;
      onTestLog: (callback: (message: string) => void) => void;
    };
  }
}

/**
 * Options sent to the main process
 */
interface RunOptions {
  test: string;
  site?: string;
  browser: 'chromium' | 'firefox' | 'webkit';
  runs: number;
  headless: boolean;
  screenshot: boolean;
  report: boolean;

  // Optional login credentials
  username?: string;
  password?: string;

  // Optional URL and environment for site-specific tests blah blah
  url?: string;
  environment?: 'dev' | 'qa' | 'prod';
}

/* ------------------------------------------------------------------ */
/* DOM ELEMENT REFERENCES                                              */
/* ------------------------------------------------------------------ */

const siteSelect = document.getElementById('site') as HTMLSelectElement | null;
const testSelect = document.getElementById('test') as HTMLSelectElement;
const browserSelect = document.getElementById('browser') as HTMLSelectElement;

const runsInput = document.getElementById('runs') as HTMLInputElement;
const headlessCheck = document.getElementById('headless') as HTMLInputElement;
const screenshotCheck = document.getElementById('screenshot') as HTMLInputElement;
const reportCheck = document.getElementById('report') as HTMLInputElement;

const runBtn = document.getElementById('runBtn') as HTMLButtonElement;
const cancelBtn = document.getElementById('cancelBtn') as HTMLButtonElement;

const outputBox = document.getElementById('output') as HTMLPreElement;
const statusLabel = document.getElementById('status') as HTMLDivElement;
const progressBar = document.getElementById('progress') as HTMLDivElement;

const testContainer = document.getElementById('test-container') as HTMLDivElement | null;

/* ------------------------------------------------------------------ */
/* STATE                                                              */
/* ------------------------------------------------------------------ */

let running = false;
let completedRuns = 0;

/* ------------------------------------------------------------------ */
/* UI STATE MANAGEMENT                                                */
/* ------------------------------------------------------------------ */

function updateRunButtonState(): void {
  if (running) {
    runBtn.disabled = true;
    return;
  }

  const siteSelected = siteSelect?.value !== '';
  const browserSelected = browserSelect.value !== '';

  const testRequired = testContainer?.hidden === false;
  const testSelected = testRequired ? testSelect.value !== '' : true;

  runBtn.disabled = !(siteSelected && browserSelected && testSelected);
}

/* ------------------------------------------------------------------ */
/* SITE SELECTION → SHOW / HIDE TEST DROPDOWN                          */
/* ------------------------------------------------------------------ */

// if (siteSelect && testContainer) {
//   siteSelect.addEventListener('change', () => {
//     const isArena = siteSelect.value === 'arena';

//     testContainer.hidden = !isArena;

//     if (!isArena) {
//       testSelect.value = '';
//     }

//     updateRunButtonState();
//   });
// }

/* ------------------------------------------------------------------ */
/* SITE SELECTION → FILTER TEST OPTIONS                                */
/* ------------------------------------------------------------------ */

if (siteSelect) {
  siteSelect.addEventListener('change', () => {
    const selectedSite = siteSelect.value;

    Array.from(testSelect.options).forEach(option => {
      const site = option.dataset.site;

      // Always allow the placeholder option
      if (!site) {
        option.disabled = false;
        option.hidden = false;
        return;
      }

      const isAllowed = site === selectedSite;
      option.disabled = !isAllowed;
      option.hidden = !isAllowed;
    });

    // Reset invalid selection
    if (testSelect.selectedOptions[0]?.disabled) {
      testSelect.value = '';
    }

    // Remove old site-specific classes
    runBtn.classList.remove(
      'bg-blue-500', 'hover:bg-blue-700',
      'bg-green-500', 'hover:bg-green-700',
      'bg-gray-600', 'hover:bg-gray-500',
    );
    progressBar.classList.remove('bg-blue-500', 'bg-blue-600', 'bg-indigo-600');

    // Add new color based on site
    if (selectedSite === 'arena') {
      runBtn.classList.add('bg-blue-500', 'hover:bg-blue-700');
      progressBar.classList.add('bg-blue-600');
    } else if (selectedSite === 'portal') {
      runBtn.classList.add('bg-indigo-500', 'hover:bg-indigo-700');
      progressBar.classList.add('bg-indigo-600');
    } else {
      runBtn.classList.add('bg-gray-600', 'hover:bg-gray-500');
    }

    updateRunButtonState();
  });
}

/* ------------------------------------------------------------------ */
/* INPUT CHANGE LISTENERS                                              */
/* ------------------------------------------------------------------ */

browserSelect.addEventListener('change', updateRunButtonState);
testSelect.addEventListener('change', updateRunButtonState);

/* ------------------------------------------------------------------ */
/* RUN BUTTON                                                          */
/* ------------------------------------------------------------------ */

runBtn.addEventListener('click', async () => {

  if (running) return;

  running = true;
  completedRuns = 0;
  updateRunButtonState();
  cancelBtn.disabled = false;

  outputBox.textContent = '';
  statusLabel.textContent = 'Running...';
  progressBar.style.width = '0%';

  const options: RunOptions = {
    test: testSelect.value,
    site: testSelect.selectedOptions[0]?.dataset.site,
    browser: browserSelect.value.toLowerCase() as 'chromium' | 'firefox' | 'webkit',
    runs: Number(runsInput.value),
    headless: headlessCheck.checked,
    screenshot: screenshotCheck.checked,
    report: reportCheck.checked,

    username: (document.getElementById('username') as HTMLInputElement)?.value || undefined,
    password: (document.getElementById('password') as HTMLInputElement)?.value || undefined,
    url: (document.getElementById('url') as HTMLInputElement)?.value || undefined,
    environment: (document.getElementById('environment') as HTMLSelectElement)?.value as 'dev' | 'qa' | 'prod' | undefined,
  };

  appendLog('Sending options to main process...');
  appendLog(JSON.stringify(options, null, 2));


  try {
    for (let i = 0; i < options.runs; i++) {
      completedRuns = i;
      // appendLog(`Run clicked. Options: ${JSON.stringify(options)}`);
      appendLog(`\nRun ${i + 1} of ${options.runs}...`);

      const result = await window.api.runTest(options);

      // appendLog(result);

      // Update progress bar incrementally
      progressBar.style.width = `${((i + 1) / options.runs) * 100}%`;
    }

    statusLabel.textContent = 'Completed';
  } catch (err: any) {
    appendLog(`Error: ${err.message}`);
    statusLabel.textContent = 'Error';
  }

  running = false;
  cancelBtn.disabled = true;
  updateRunButtonState();
});

/* ------------------------------------------------------------------ */
/* CANCEL BUTTON                                                       */
/* ------------------------------------------------------------------ */

cancelBtn.addEventListener('click', () => {
  appendLog('Cancel clicked (not wired yet)');
});

/* ------------------------------------------------------------------ */
/* LOGGING                                                             */
/* ------------------------------------------------------------------ */

function appendLog(message: string): void {
  const timestamp = new Date().toLocaleTimeString();
  outputBox.textContent += `[${timestamp}] ${message}\n`;
  outputBox.scrollTop = outputBox.scrollHeight;
}

/* ------------------------------------------------------------------ */
/* Subscribe                                         */
/* ------------------------------------------------------------------ */
window.api.onTestLog((msg) => {
  appendLog(msg);
});

/* ------------------------------------------------------------------ */
/* INITIAL UI SYNC                                                     */
/* ------------------------------------------------------------------ */
updateRunButtonState();
