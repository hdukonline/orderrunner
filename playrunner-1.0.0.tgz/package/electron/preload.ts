import { contextBridge, ipcRenderer } from 'electron';
import type { RunOptions } from '../playwright/runner.js';

contextBridge.exposeInMainWorld('api', {
  // One-shot call to start the test
  runTest: (options: RunOptions) => ipcRenderer.invoke('run-test', options),

  // Listener for streaming log messages from the test
  onTestLog: (callback: (message: string) => void) => {
    ipcRenderer.on('test-log', (_, message: string) => callback(message));
  }
});