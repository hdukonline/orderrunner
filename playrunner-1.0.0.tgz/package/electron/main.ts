import path from "path";
import { ipcMain, app, BrowserWindow, screen } from "electron";
import { runTest, RunOptions } from '../playwright/runner.js';

/**
 * ----------------------------
 * DPI Fix for Windows
 * ----------------------------
 * Ensures Windows does not auto-scale your app window
 * This prevents tiny/huge UI on high-DPI monitors.
 */
if (process.platform === 'win32') {
  app.commandLine.appendSwitch('high-dpi-support', 'true');
  app.commandLine.appendSwitch('force-device-scale-factor', '1');
}

/**
 * ----------------------------
 * IPC handler
 * ----------------------------
 * Allows renderer to call your Playwright runner and stream logs back.
 */
ipcMain.handle('run-test', async (event, options: RunOptions) => {
  const webContents = event.sender;
  return await runTest(options, (message: string) => {
    webContents.send('test-log', message);
  });
});

/**
 * ----------------------------
 * Create the main window
 * ----------------------------
 */
function createWindow() {
  const primaryDisplay = screen.getPrimaryDisplay();
  const scale = primaryDisplay.scaleFactor || 1;

  const win = new BrowserWindow({
    minWidth: 400,
    minHeight: 800,
    webPreferences: {
      preload: path.resolve(app.getAppPath(), 'dist/electron/preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  const indexPath = path.join(app.getAppPath(), 'dist/ui/index.html');
  win.loadFile(indexPath);

  /**
   * ----------------------------
   * Zoom-out adjustment
   * ----------------------------
   */
  const zoomOutMultiplier = 0.85;
  win.webContents.setZoomFactor(zoomOutMultiplier / scale);

  // Optional: open DevTools for debugging
  // win.webContents.openDevTools();
}

/**
 * ----------------------------
 * Handle multi-monitor scaling
 * ----------------------------
 * Adjust zoom if window moves to a monitor with different DPI.
 */
app.on('browser-window-created', (_e, window) => {
  window.on('move', () => {
    const scale = screen.getDisplayMatching(window.getBounds()).scaleFactor;
    const zoomOutMultiplier = 0.85; // <-- SAME VALUE HERE FOR CONSISTENCY
    window.webContents.setZoomFactor(zoomOutMultiplier / scale);
  });
});

/**
 * ----------------------------
 * App lifecycle
 * ----------------------------
 */
app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});