/** @type {import('tailwindcss').Config} */
module.exports = {
content: [
  "./index.html",
  "./ui/**/*.{ts,tsx,js,jsx,html}",
],
  theme: {
    extend: {},
  },
  plugins: [],
}